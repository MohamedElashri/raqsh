import { execFile } from "node:child_process";
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { promisify } from "node:util";

const root = fileURLToPath(new URL("../", import.meta.url));
const desktop = join(root, "apps/desktop");
const tauriBase = JSON.parse(readFileSync(join(desktop, "src-tauri/tauri.base.json"), "utf8"));
const run = promisify(execFile);

function writeGenerated(path, content) {
  const bytes = Buffer.from(content);
  if (existsSync(path) && readFileSync(path).equals(bytes)) return;
  mkdirSync(dirname(path), { recursive: true });
  writeFileSync(path, bytes);
}

function readBrand(sources) {
  const { displayName, tagline, accent } = JSON.parse(readFileSync(join(sources, "brand.json"), "utf8"));
  if (typeof displayName !== "string" || !displayName.trim() || /[\u0000-\u001f\u007f/\\]/u.test(displayName)) {
    throw new Error("Brand displayName must be a nonempty name without control characters or path separators.");
  }
  if (typeof tagline !== "string" || typeof accent !== "string" || !/^#[0-9a-f]{6}$/i.test(accent)) {
    throw new Error("Brand requires a tagline and a six-digit accent color.");
  }
  return { displayName, tagline, accent };
}

export async function generateBrand(sources = join(root, "branding"), output = desktop) {
  const brand = readBrand(sources);
  const iconPath = join(sources, "icon.svg");
  const tauri = structuredClone(tauriBase);
  tauri.app.windows[0].title = brand.displayName;
  const markupEscapes = { "&": "&amp;", "<": "&lt;", ">": "&gt;" };
  const plistName = brand.displayName.replace(/[&<>]/g, (character) => markupEscapes[character]);
  const desktopName = brand.displayName.replaceAll("{{", "\\{{");

  const scratch = mkdtempSync(join(tmpdir(), "visual-board-icons-"));
  try {
    await run("pnpm", ["exec", "tauri", "icon", iconPath, "--output", scratch], { cwd: root });
    for (const icon of tauri.bundle.icon) {
      writeGenerated(join(output, "src-tauri", icon), readFileSync(join(scratch, icon.slice("icons/".length))));
    }
    writeGenerated(join(output, "src-tauri/tauri.conf.json"), `${JSON.stringify(tauri, null, 2)}\n`);
    writeGenerated(join(output, "src-tauri/generated/main.desktop"), `[Desktop Entry]
Type=Application
Name=${desktopName}
Comment={{comment}}
Exec={{exec}}
Icon={{icon}}
Categories={{categories}}
StartupWMClass={{icon}}
Terminal=false
`);
    writeGenerated(join(output, "src-tauri/generated/Info.plist"), `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleDisplayName</key><string>${plistName}</string>
  <key>CFBundleName</key><string>${plistName}</string>
</dict></plist>
`);
    writeGenerated(join(output, "src/generated/icon.svg"), readFileSync(iconPath));
    writeGenerated(join(output, "src/generated/brand.css"), `:root { --brand-accent: ${brand.accent}; }\n`);
    writeGenerated(join(output, "src/generated/brand.ts"), `export const brand = ${JSON.stringify(brand, null, 2)} as const;\n`);
  } finally {
    rmSync(scratch, { force: true, recursive: true });
  }
}

if (import.meta.url === pathToFileURL(process.argv[1]).href) {
  await generateBrand();
}
