use tauri::WebviewWindowBuilder;

mod probe;

fn main() -> tauri::Result<()> {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![
            probe::validate_preview,
            probe::preview_backend_delta
        ])
        .setup(|app| {
            let config = app.config();
            let dev_origin = if cfg!(feature = "custom-protocol") {
                None
            } else {
                config.build.dev_url.as_ref().map(|url| url.origin())
            };

            let mut window = WebviewWindowBuilder::from_config(app, &config.app.windows[0])?
                .on_navigation(move |url| {
                    (url.scheme() == "tauri" && url.host_str() == Some("localhost"))
                        || dev_origin.as_ref() == Some(&url.origin())
                })
                .on_new_window(|_, _| tauri::webview::NewWindowResponse::Deny);
            if let Some(fixture) = std::env::args().find_map(|arg| match arg.as_str() {
                "--fixture=empty" => Some("empty"),
                "--fixture=tiny" => Some("tiny"),
                "--fixture=ordinary" => Some("ordinary"),
                "--fixture=normal" => Some("normal"),
                _ => None,
            }) {
                window = window
                    .initialization_script(format!("window.__BOARD_FIXTURE__ = '{fixture}';"));
            }
            if std::env::args().any(|arg| arg == "--phase-zero-probe") {
                window = window.initialization_script("window.__PHASE_ZERO_PROBE__ = true;");
            }
            window.build()?;
            Ok(())
        })
        .run(tauri::generate_context!())
}
