use serde::{Deserialize, Serialize};

#[derive(Deserialize, Serialize)]
pub struct CardDelta {
    id: String,
    x: f64,
    y: f64,
    title: String,
}

#[tauri::command]
pub fn validate_preview(cards: Vec<CardDelta>) -> Result<Vec<CardDelta>, &'static str> {
    if cards.is_empty() || cards.len() > 8 || cards.iter().any(|card| !valid_card(card)) {
        return Err("Invalid fixture card update");
    }
    Ok(cards)
}

fn valid_card(card: &CardDelta) -> bool {
    card.id
        .strip_prefix("task-")
        .and_then(|number| number.parse::<u16>().ok())
        .is_some_and(|number| (1..=200).contains(&number))
        && (-20_000.0..=20_000.0).contains(&card.x)
        && (-20_000.0..=20_000.0).contains(&card.y)
        && !card.title.trim().is_empty()
        && card.title.len() <= 1024
}

#[tauri::command]
pub fn preview_backend_delta() -> CardDelta {
    CardDelta {
        id: "task-2".to_owned(),
        x: 398.0,
        y: 80.0,
        title: "Backend-confirmed label".to_owned(),
    }
}
