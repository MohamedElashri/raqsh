fn main() {
    tauri_build::try_build(tauri_build::Attributes::new().app_manifest(
        tauri_build::AppManifest::new().commands(&["validate_preview", "preview_backend_delta"]),
    ))
    .expect("build desktop capabilities");
}
