import { lazy, Suspense, useState } from "react";
import { createRoot } from "react-dom/client";
import { type BoardSize } from "../../../bench/fixtures/boards";
import { brand } from "./generated/brand";
import icon from "./generated/icon.svg";
import "./generated/brand.css";
import "./style.css";

declare global {
  interface Window {
    EXCALIDRAW_ASSET_PATH?: string;
    __BOARD_FIXTURE__?: string;
    __PHASE_ZERO_PROBE__?: boolean;
  }
}

const Editor = import.meta.env.VITE_TAURI_SHELL === "1"
  ? null
  : import.meta.env.VITE_BOARD_RENDERER === "lean"
    ? lazy(() => import("./lean/LeanEditor"))
    : lazy(() => {
      window.EXCALIDRAW_ASSET_PATH = new URL("./", document.baseURI).href;
      return import("./BoardEditor");
    });

const fixtures: Record<BoardSize, string> = {
  empty: "Empty board",
  tiny: "Tiny sample",
  ordinary: "Ordinary sample",
  normal: "Normal sample",
};

function isBoardSize(value: string | undefined): value is BoardSize {
  return value !== undefined && Object.hasOwn(fixtures, value);
}

function Workspace() {
  const defaultBoard = window.__BOARD_FIXTURE__;
  const [size, setSize] = useState<BoardSize>(isBoardSize(defaultBoard) ? defaultBoard : "empty");
  const [open, setOpen] = useState(isBoardSize(defaultBoard));

  if (open && Editor) {
    return (
      <main className="board-workspace">
        <header className="board-header">
          <button type="button" onClick={() => setOpen(false)}>Close board</button>
          <h1>{fixtures[size]}</h1>
        </header>
        <Suspense fallback={<p role="status" className="board-loading">Opening board…</p>}>
          <Editor size={size} />
        </Suspense>
      </main>
    );
  }

  return (
    <main className="workspace">
      <div className="app-mark">
        <img src={icon} width="76" height="76" alt="" />
        <h1>{brand.displayName}</h1>
        {Editor && (
          <div className="board-picker">
            <label htmlFor="board-size">Demo board</label>
            <select id="board-size" value={size} onChange={(event) => {
              const value = event.target.value;
              if (isBoardSize(value)) setSize(value);
            }}>
              {Object.entries(fixtures).map(([key, label]) => <option key={key} value={key}>{label}</option>)}
            </select>
            <button type="button" onClick={() => setOpen(true)}>Open board</button>
          </div>
        )}
      </div>
    </main>
  );
}

createRoot(document.getElementById("root")!).render(<Workspace />);
