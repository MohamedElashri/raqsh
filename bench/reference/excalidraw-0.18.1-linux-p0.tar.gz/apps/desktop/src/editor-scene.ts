import { convertToExcalidrawElements, FONT_FAMILY } from "@excalidraw/excalidraw";
import type { ExcalidrawFreeDrawElement } from "@excalidraw/excalidraw/element/types";
import { createBoardFixture, type BoardSize } from "../../../bench/fixtures/boards";

export function createEditorScene(size: BoardSize) {
  const { nodes, edges, strokes } = createBoardFixture(size);
  const projected = convertToExcalidrawElements([
    ...nodes.map((node) => ({
      type: "rectangle" as const,
      id: node.id,
      x: node.x,
      y: node.y,
      width: node.width,
      height: node.height,
      strokeColor: "#356756",
      backgroundColor: "#e4f3eb",
      fillStyle: "solid" as const,
      roughness: 0,
      label: { text: node.title, fontSize: 15, fontFamily: FONT_FAMILY.Nunito },
      customData: { nodeId: node.id },
    })),
    ...edges.map((edge) => ({
      type: "arrow" as const,
      id: edge.id,
      x: edge.from.x + edge.from.width,
      y: edge.from.y + edge.from.height / 2,
      start: { id: edge.from.id },
      end: { id: edge.to.id },
      strokeColor: "#697872",
      roughness: 0,
      customData: { edgeId: edge.id },
    })),
  ], { regenerateIds: false });

  const labelIds = new Map<string, string>();
  for (const element of projected) {
    if (element.type === "text" && element.containerId) {
      labelIds.set(element.id, `${element.containerId}-label`);
    }
  }

  const freehand = strokes.map((stroke): ExcalidrawFreeDrawElement => ({
    type: "freedraw",
    id: stroke.id,
    x: stroke.x,
    y: stroke.y,
    width: stroke.points.at(-1)![0],
    height: Math.max(...stroke.points.map((point) => point[1])) - Math.min(...stroke.points.map((point) => point[1])),
    points: stroke.points as ExcalidrawFreeDrawElement["points"],
    pressures: [],
    simulatePressure: true,
    lastCommittedPoint: null,
    angle: 0 as ExcalidrawFreeDrawElement["angle"],
    strokeColor: "#236b58",
    backgroundColor: "transparent",
    fillStyle: "solid",
    strokeWidth: 2,
    strokeStyle: "solid",
    roundness: null,
    roughness: 0,
    opacity: 100,
    seed: 1,
    version: 1,
    versionNonce: 1,
    index: null,
    isDeleted: false,
    groupIds: [],
    frameId: null,
    boundElements: null,
    updated: 0,
    link: null,
    locked: false,
  }));

  // The embed restores its initial scene, including indices and bindings.
  return [...projected, ...freehand].map((element, offset) => ({
    ...element,
    id: labelIds.get(element.id) ?? element.id,
    seed: offset + 1,
    versionNonce: offset + 1,
    updated: 0,
    boundElements: element.boundElements?.map((binding) => ({
      ...binding,
      id: labelIds.get(binding.id) ?? binding.id,
    })) ?? null,
  }));
}
