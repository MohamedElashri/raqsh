import { createBoardFixture, type BoardSize } from "../../../../bench/fixtures/boards";

export type Point = [number, number];
export type Card = ReturnType<typeof createBoardFixture>["nodes"][number];
export type CardDelta = Pick<Card, "id" | "x" | "y" | "title">;
export type View = { x: number; y: number; zoom: number };
export type Board = {
  nodes: Card[];
  edges: { id: string; from: string; to: string }[];
  strokes: ReturnType<typeof createBoardFixture>["strokes"];
  labels: { x: number; y: number; text: string }[];
};

export function openFixture(size: BoardSize): Board {
  const fixture = createBoardFixture(size);
  const board: Board = {
    nodes: fixture.nodes,
    edges: fixture.edges.map(({ id, from, to }) => ({ id, from: from.id, to: to.id })),
    strokes: fixture.strokes,
    labels: [],
  };
  if (!window.__PHASE_ZERO_PROBE__) return board;
  try {
    const saved = sessionStorage.getItem(`fixture:${size}`);
    if (saved) return JSON.parse(saved) as Board;
  } catch {
    // An unavailable browser session store leaves the deterministic fixture usable.
  }
  return board;
}

const colors = { fill: "#e4f3eb", border: "#356756", edge: "#697872", ink: "#236b58", text: "#1c2421" };

function edgePoints(from: Card, to: Card): Point[] {
  const start: Point = [from.x + from.width, from.y + from.height / 2];
  const end: Point = [to.x, to.y + to.height / 2];
  const angle = Math.atan2(end[1] - start[1], end[0] - start[0]);
  const tip = (offset: number): Point => [end[0] - 12 * Math.cos(angle + offset), end[1] - 12 * Math.sin(angle + offset)];
  return [start, end, tip(0.45), end, tip(-0.45)];
}

function paths(board: Board, draw: (points: readonly Point[], color: string, width: number, x: number, y: number) => void) {
  const byId = new Map(board.nodes.map((node) => [node.id, node]));
  for (const edge of board.edges) {
    const from = byId.get(edge.from);
    const to = byId.get(edge.to);
    if (from && to) draw(edgePoints(from, to), colors.edge, 1.5, 0, 0);
  }
  for (const stroke of board.strokes) draw(stroke.points, colors.ink, 3, stroke.x, stroke.y);
}

export function paintPaths(context: CanvasRenderingContext2D, board: Board) {
  context.lineCap = "round";
  context.lineJoin = "round";
  paths(board, (points, color, width, x, y) => {
    if (!points.length) return;
    context.beginPath();
    context.strokeStyle = color;
    context.lineWidth = width;
    context.moveTo(x + points[0][0], y + points[0][1]);
    for (const [px, py] of points.slice(1)) context.lineTo(x + px, y + py);
    context.stroke();
  });
}

const xml = (value: string) => value.replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&apos;" })[character]!);

function bounds(board: Board) {
  const xs = [0];
  const ys = [0];
  for (const node of board.nodes) { xs.push(node.x, node.x + node.width); ys.push(node.y, node.y + node.height); }
  for (const stroke of board.strokes) {
    for (const [x, y] of stroke.points) { xs.push(stroke.x + x); ys.push(stroke.y + y); }
  }
  for (const label of board.labels) { xs.push(label.x, label.x + 240); ys.push(label.y, label.y + 22); }
  const x = Math.min(...xs) - 18;
  const y = Math.min(...ys) - 18;
  return { x, y, width: Math.max(...xs) - x + 18, height: Math.max(...ys) - y + 18 };
}

function rtl(text: string) {
  const firstLetter = text.match(/\p{Letter}/u)?.[0];
  return firstLetter !== undefined && /[\p{Script=Arabic}\p{Script=Hebrew}]/u.test(firstLetter);
}

function lines(context: CanvasRenderingContext2D, text: string, width: number) {
  return text.split("\n").flatMap((paragraph) => {
    const wrapped: string[] = [];
    let line = "";
    for (const word of paragraph.split(/\s+/)) {
      const joined = line ? `${line} ${word}` : word;
      if (line && context.measureText(joined).width > width) {
        wrapped.push(line);
        line = word;
      } else line = joined;
    }
    wrapped.push(line);
    return wrapped;
  });
}

export function exportFixture(board: Board, format: "png" | "svg"): Promise<Blob> {
  const region = bounds(board);
  const canvas = document.createElement("canvas");
  const scale = Math.min(1, 4096 / Math.max(region.width, region.height));
  if (format === "png") {
    canvas.width = Math.ceil(region.width * scale);
    canvas.height = Math.ceil(region.height * scale);
  }
  const context = canvas.getContext("2d")!;
  context.font = "15px system-ui";
  const cardLines = board.nodes.map((node) => lines(context, node.title, node.width - 24));
  if (format === "svg") {
    const geometry: string[] = [];
    paths(board, (points, color, width, x, y) => geometry.push(`<polyline points="${points.map(([px, py]) => `${px + x},${py + y}`).join(" ")}" fill="none" stroke="${color}" stroke-width="${width}" stroke-linecap="round"/>`));
    const label = (x: number, y: number, text: string, align: "middle" | "start") => `<text x="${x}" y="${y}" text-anchor="${align}" direction="${rtl(text) ? "rtl" : "ltr"}" unicode-bidi="embed">${xml(text)}</text>`;
    for (const [index, node] of board.nodes.entries()) {
      geometry.push(`<rect x="${node.x}" y="${node.y}" width="${node.width}" height="${node.height}" rx="4" fill="${colors.fill}" stroke="${colors.border}"/>`);
      const rows = cardLines[index];
      for (const [row, text] of rows.entries()) geometry.push(label(node.x + node.width / 2, node.y + node.height / 2 + (row - (rows.length - 1) / 2) * 18 + 5, text, "middle"));
    }
    for (const item of board.labels) geometry.push(label(item.x, item.y, item.text, "start"));
    return Promise.resolve(new Blob([`<svg xmlns="http://www.w3.org/2000/svg" viewBox="${region.x} ${region.y} ${region.width} ${region.height}" font-family="system-ui" font-size="15" fill="${colors.text}">${geometry.join("")}</svg>`], { type: "image/svg+xml" }));
  }
  context.scale(scale, scale);
  context.translate(-region.x, -region.y);
  context.fillStyle = "#ffffff";
  context.fillRect(region.x, region.y, region.width, region.height);
  paintPaths(context, board);
  for (const [index, node] of board.nodes.entries()) {
    context.fillStyle = colors.fill;
    context.fillRect(node.x, node.y, node.width, node.height);
    context.strokeStyle = colors.border;
    context.lineWidth = 1;
    context.strokeRect(node.x, node.y, node.width, node.height);
    context.fillStyle = colors.text;
    context.textAlign = "center";
    const rows = cardLines[index];
    for (const [row, text] of rows.entries()) {
      context.direction = rtl(text) ? "rtl" : "ltr";
      context.fillText(text, node.x + node.width / 2, node.y + node.height / 2 + (row - (rows.length - 1) / 2) * 18 + 5);
    }
  }
  for (const label of board.labels) {
    context.direction = rtl(label.text) ? "rtl" : "ltr";
    context.textAlign = "start";
    context.fillText(label.text, label.x, label.y);
  }
  return new Promise((resolve, reject) => canvas.toBlob((blob) => blob ? resolve(blob) : reject(new Error("Could not encode PNG"))));
}
