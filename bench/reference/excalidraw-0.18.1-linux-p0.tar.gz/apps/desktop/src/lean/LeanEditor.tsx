import { invoke } from "@tauri-apps/api/core";
import { useCallback, useEffect, useRef, useState, type FormEvent, type PointerEvent } from "react";
import type { BoardSize } from "../../../../bench/fixtures/boards";
import { exportFixture, openFixture, paintPaths, type Board, type Card, type CardDelta, type Point, type View } from "./board";
import "../editor.css";
import "./lean.css";

type Tool = "select" | "pan" | "pen" | "text";
type Gesture =
  | { kind: "pan"; start: Point; view: View }
  | { kind: "card"; start: Point; card: Card; before: CardDelta }
  | { kind: "pen"; stroke: Board["strokes"][number] };
type Edit = { card: Card; title: string } | { point: Point; title: string };

const tools: { id: Tool; label: string }[] = [
  { id: "select", label: "Select" }, { id: "pan", label: "Pan" },
  { id: "pen", label: "Freehand" }, { id: "text", label: "Text" },
];

export default function LeanEditor({ size }: { size: BoardSize }) {
  const [board] = useState(() => openFixture(size));
  const [tool, setTool] = useState<Tool>("select");
  const [selected, setSelected] = useState<string>();
  const [edit, setEdit] = useState<Edit>();
  const [status, setStatus] = useState("");
  const [download, setDownload] = useState<{ url: string; format: string; bytes: number }>();
  const [, refreshLabels] = useState(0);
  const panel = useRef<HTMLDivElement>(null);
  const canvas = useRef<HTMLCanvasElement>(null);
  const cardsLayer = useRef<HTMLDivElement>(null);
  const cards = useRef(new Map<string, HTMLButtonElement>());
  const gesture = useRef<Gesture>();
  const view = useRef<View>({ x: 0, y: 0, zoom: 1 });
  const undo = useRef<CardDelta[]>([]);
  const space = useRef(false);
  const alive = useRef(false);
  const busy = useRef(false);
  const frame = useRef(0);
  const preview = window.__PHASE_ZERO_PROBE__ === true;

  const repaint = useCallback(() => {
    if (frame.current) return;
    frame.current = requestAnimationFrame(() => {
      frame.current = 0;
      const surface = canvas.current;
      if (!surface || !cardsLayer.current) return;
      const ratio = window.devicePixelRatio;
      const width = Math.round(surface.clientWidth * ratio);
      const height = Math.round(surface.clientHeight * ratio);
      if (surface.width !== width) surface.width = width;
      if (surface.height !== height) surface.height = height;
      const context = surface.getContext("2d")!;
      const camera = view.current;
      context.setTransform(1, 0, 0, 1, 0, 0);
      context.clearRect(0, 0, width, height);
      context.setTransform(ratio * camera.zoom, 0, 0, ratio * camera.zoom, ratio * camera.x, ratio * camera.y);
      paintPaths(context, board);
      cardsLayer.current.style.transform = `translate(${camera.x}px, ${camera.y}px) scale(${camera.zoom})`;
      if (panel.current) panel.current.dataset.editorReady = "true";
    });
  }, [board]);

  useEffect(() => {
    alive.current = true;
    const observer = new ResizeObserver(repaint);
    if (canvas.current) observer.observe(canvas.current);
    repaint();
    const release = () => { space.current = false; };
    window.addEventListener("blur", release);
    return () => {
      alive.current = false;
      observer.disconnect();
      cancelAnimationFrame(frame.current);
      window.removeEventListener("blur", release);
    };
  }, [repaint]);

  useEffect(() => () => {
    if (download) URL.revokeObjectURL(download.url);
  }, [download]);

  function showCard(card: Card) {
    const button = cards.current.get(card.id);
    if (button) {
      button.style.left = `${card.x}px`;
      button.style.top = `${card.y}px`;
    }
  }

  function count(key: "nativeBatches" | "drawingChanges") {
    if (panel.current) panel.current.dataset[key] = String(Number(panel.current.dataset[key] ?? 0) + 1);
  }

  async function applyCard(card: Card, delta: CardDelta, before: CardDelta, remember: boolean) {
    busy.current = true;
    try {
      let approved = delta;
      if (preview) {
        const reply = await invoke<CardDelta[]>("validate_preview", { cards: [delta] });
        approved = reply[0];
        count("nativeBatches");
      }
      if (!alive.current) return;
      if (remember) {
        undo.current.push(before);
        if (undo.current.length > 32) undo.current.shift();
      }
      Object.assign(card, approved);
      showCard(card);
      refreshLabels((value) => value + 1);
      repaint();
      setStatus("");
    } catch {
      if (!alive.current) return;
      Object.assign(card, before);
      showCard(card);
      repaint();
      setStatus("Card change could not be confirmed.");
    } finally {
      busy.current = false;
    }
  }

  async function undoCard() {
    if (busy.current) return;
    const prior = undo.current.pop();
    const card = prior && board.nodes.find((item) => item.id === prior.id);
    if (card && prior) await applyCard(card, prior, { ...card }, false);
  }

  function point(event: PointerEvent<HTMLCanvasElement>, convert = true): Point {
    const rect = event.currentTarget.getBoundingClientRect();
    const position: Point = [event.clientX - rect.left, event.clientY - rect.top];
    const camera = view.current;
    return convert ? [(position[0] - camera.x) / camera.zoom, (position[1] - camera.y) / camera.zoom] : position;
  }

  function hit([x, y]: Point) {
    for (let index = board.nodes.length - 1; index >= 0; index--) {
      const card = board.nodes[index];
      if (x >= card.x && x <= card.x + card.width && y >= card.y && y <= card.y + card.height) return card;
    }
  }

  function start(event: PointerEvent<HTMLCanvasElement>) {
    if (event.button !== 0 || busy.current || gesture.current) return;
    event.currentTarget.focus();
    const start = point(event);
    if (tool === "pan" || space.current) {
      gesture.current = { kind: "pan", start: point(event, false), view: { ...view.current } };
    } else if (tool === "pen") {
      const stroke = { id: `annotation-${board.strokes.length}`, x: start[0], y: start[1], points: [[0, 0]] as Point[] };
      board.strokes.push(stroke);
      gesture.current = { kind: "pen", stroke };
    } else if (tool === "text") {
      const card = hit(start);
      setEdit(card ? { card, title: card.title } : { point: start, title: "" });
      return;
    } else {
      const card = hit(start);
      setSelected(card?.id);
      if (!card) return;
      gesture.current = { kind: "card", start, card, before: { ...card } };
    }
    event.currentTarget.setPointerCapture(event.pointerId);
  }

  function move(event: PointerEvent<HTMLCanvasElement>) {
    const active = gesture.current;
    if (!active) return;
    if (active.kind === "pan") {
      const [x, y] = point(event, false);
      view.current.x = active.view.x + x - active.start[0];
      view.current.y = active.view.y + y - active.start[1];
    } else if (active.kind === "card") {
      const [x, y] = point(event);
      active.card.x = active.before.x + x - active.start[0];
      active.card.y = active.before.y + y - active.start[1];
      showCard(active.card);
    } else if (active.stroke.points.length < 1024) {
      const [x, y] = point(event);
      active.stroke.points.push([x - active.stroke.x, y - active.stroke.y]);
    }
    repaint();
  }

  function finish(canceled: boolean) {
    const active = gesture.current;
    gesture.current = undefined;
    if (!active) return;
    if (active.kind === "card") {
      if (canceled) {
        Object.assign(active.card, active.before);
        showCard(active.card);
      } else if (active.card.x !== active.before.x || active.card.y !== active.before.y) {
        void applyCard(active.card, { ...active.card }, active.before, true);
      }
    } else if (active.kind === "pen") {
      if (canceled || active.stroke.points.length < 2) board.strokes.pop();
      else count("drawingChanges");
    }
    repaint();
  }

  function enterText(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!edit || busy.current) return;
    const text = String(new FormData(event.currentTarget).get("label") ?? "").trim();
    if (!text) return;
    if ("card" in edit) {
      void applyCard(edit.card, { ...edit.card, title: text }, { ...edit.card }, true);
    } else {
      board.labels.push({ x: edit.point[0], y: edit.point[1], text });
      count("drawingChanges");
      refreshLabels((value) => value + 1);
    }
    setEdit(undefined);
    canvas.current?.focus();
  }

  async function injectDelta() {
    if (busy.current) return;
    try {
      const delta = await invoke<CardDelta>("preview_backend_delta");
      if (!alive.current) return;
      const card = board.nodes.find((node) => node.id === delta.id);
      if (!card) return;
      Object.assign(card, delta);
      showCard(card);
      refreshLabels((value) => value + 1);
      repaint();
    } catch {
      if (alive.current) setStatus("Backend update could not be loaded.");
    }
  }

  function saveFixture() {
    try {
      sessionStorage.setItem(`fixture:${size}`, JSON.stringify(board));
      setStatus("Fixture saved for this session.");
    } catch {
      setStatus("Fixture could not be saved.");
    }
  }

  async function prepareExport(format: "png" | "svg") {
    try {
      const blob = await exportFixture(board, format);
      if (alive.current) setDownload({ url: URL.createObjectURL(blob), format, bytes: blob.size });
    } catch {
      if (alive.current) setStatus("Board export could not be prepared.");
    }
  }

  function zoom(factor: number) {
    view.current.zoom = Math.min(2, Math.max(0.3, view.current.zoom * factor));
    repaint();
  }

  return (
    <div className="board-editor lean-editor" ref={panel} data-fixture={size}
      data-initial-elements={board.nodes.length * 2 + board.edges.length + board.strokes.length} data-renderer="lean"
      onKeyDown={(event) => {
        if (event.target !== canvas.current) return;
        if (event.key === " ") { event.preventDefault(); space.current = true; }
        if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "z") { event.preventDefault(); void undoCard(); }
      }} onKeyUp={(event) => { if (event.key === " ") space.current = false; }}>
      <canvas ref={canvas} className={`interactive lean-canvas tool-${tool}`} data-board-surface tabIndex={0} aria-label="Drawing canvas"
        onPointerDown={start} onPointerMove={move} onPointerUp={() => finish(false)} onPointerCancel={() => finish(true)}
        onDoubleClick={(event) => {
          const rect = event.currentTarget.getBoundingClientRect();
          const camera = view.current;
          const card = hit([(event.clientX - rect.left - camera.x) / camera.zoom, (event.clientY - rect.top - camera.y) / camera.zoom]);
          if (card) setEdit({ card, title: card.title });
        }} />
      <div className="lean-cards" ref={cardsLayer}>
        {board.nodes.map((card) => (
          <button key={card.id} type="button" dir="auto" className="lean-card" data-card-id={card.id} aria-pressed={selected === card.id}
            ref={(element) => { if (element) cards.current.set(card.id, element); else cards.current.delete(card.id); }}
            style={{ left: card.x, top: card.y, width: card.width, height: card.height }} onClick={() => setEdit({ card, title: card.title })}>{card.title}</button>
        ))}
        {board.labels.map((label, index) => <span className="lean-label" dir="auto" key={index} style={{ left: label.x, top: label.y }}>{label.text}</span>)}
      </div>
      <div className="lean-toolbar" role="toolbar" aria-label="Board tools">
        {tools.map(({ id, label }) => <button key={id} type="button" data-tool={id} aria-pressed={tool === id} onClick={() => setTool(id)}>{label}</button>)}
        <button className="zoom-in-button" type="button" onClick={() => zoom(1.1)} aria-label="Zoom in">+</button>
        <button type="button" onClick={() => zoom(1 / 1.1)} aria-label="Zoom out">−</button>
        <button type="button" onClick={() => void undoCard()}>Undo card</button>
        <button type="button" onClick={() => void prepareExport("png")}>Export PNG</button>
        <button type="button" onClick={() => void prepareExport("svg")}>Export SVG</button>
        {download && <a href={download.url} download={`board.${download.format}`} data-export-bytes={download.bytes}>Download {download.format.toUpperCase()}</a>}
      </div>
      {preview && <div className="lean-preview" aria-label="Fixture checks">
        <button type="button" onClick={saveFixture}>Save fixture</button>
        <button type="button" onClick={() => void injectDelta()}>Apply backend sample</button>
      </div>}
      {edit && <form className="lean-edit" onSubmit={enterText}>
        <label>Board text<textarea name="label" dir="auto" autoFocus defaultValue={edit.title} maxLength={256} /></label>
        <button type="submit">Apply text</button>
        <button type="button" onClick={() => setEdit(undefined)}>Cancel</button>
      </form>}
      {status && <output className="lean-status">{status}</output>}
    </div>
  );
}
