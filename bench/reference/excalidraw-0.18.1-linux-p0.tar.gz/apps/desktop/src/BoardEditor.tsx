import { DefaultSidebar, Excalidraw, MainMenu } from "@excalidraw/excalidraw";
import type { ExcalidrawProps } from "@excalidraw/excalidraw/types";
import { useCallback, useRef } from "react";
import type { BoardSize } from "../../../bench/fixtures/boards";
import { createEditorScene } from "./editor-scene";
import "@excalidraw/excalidraw/index.css";
import "./editor.css";

const editorOptions: ExcalidrawProps["UIOptions"] = {
  canvasActions: { export: false, loadScene: false, saveToActiveFile: false },
  tools: { image: false },
};

export default function BoardEditor({ size }: { size: BoardSize }) {
  const panel = useRef<HTMLDivElement>(null);
  const initialData = useCallback(() => ({ elements: createEditorScene(size) }), [size]);
  const markReady: NonNullable<ExcalidrawProps["onChange"]> = useCallback((elements, appState) => {
    if (panel.current && window.__PHASE_ZERO_PROBE__) {
      panel.current.dataset.sceneCallbacks = String(Number(panel.current.dataset.sceneCallbacks ?? 0) + 1);
    }
    if (panel.current && !panel.current.dataset.editorReady && !appState.isLoading) {
      panel.current.dataset.editorReady = "true";
      panel.current.dataset.initialElements = String(elements.length);
    }
  }, []);

  return (
    <div className="board-editor" ref={panel} data-fixture={size}>
      <Excalidraw
        initialData={initialData}
        onChange={markReady}
        UIOptions={editorOptions}
        autoFocus
        aiEnabled={false}
        validateEmbeddable={false}
        onLinkOpen={(_, event) => event.preventDefault()}
      >
        <DefaultSidebar.Trigger hidden aria-hidden tabIndex={-1}>{null}</DefaultSidebar.Trigger>
        <MainMenu>
          <MainMenu.DefaultItems.SaveAsImage />
          <MainMenu.DefaultItems.ToggleTheme />
          <MainMenu.DefaultItems.ClearCanvas />
        </MainMenu>
      </Excalidraw>
    </div>
  );
}
