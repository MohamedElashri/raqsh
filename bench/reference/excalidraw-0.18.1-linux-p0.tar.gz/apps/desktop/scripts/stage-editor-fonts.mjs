import { cp, mkdir } from "node:fs/promises";

if (process.env.VITE_TAURI_SHELL !== "1" && process.env.VITE_BOARD_RENDERER !== "lean") {
  const assets = new URL("../.generated-public/", import.meta.url);
  const sources = new URL("../node_modules/@excalidraw/excalidraw/dist/prod/fonts/", import.meta.url);
  await mkdir(assets, { recursive: true });
  await cp(sources, new URL("fonts/", assets), { recursive: true });
}
