#!/usr/bin/env python3
"""Exercise the packaged UI with Linux's external WebKit WebDriver."""

import argparse
import base64
import json
import socket
import subprocess
import time
from pathlib import Path
from urllib import error, request


def available_port():
    with socket.socket() as listener:
        listener.bind(("127.0.0.1", 0))
        return listener.getsockname()[1]


def wait_until(check, description, timeout=10):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            if value := check():
                return value
        except (ConnectionError, error.URLError):
            pass
        time.sleep(0.05)
    raise RuntimeError(f"Timed out waiting for {description}.")


def exercise_input(send, session, evaluate, click):
    def move(x, y):
        return {"type": "pointerMove", "x": x, "y": y, "origin": "viewport", "duration": 120}

    def pointer(steps, pan=False):
        actions = [{"type": "pointer", "id": "mouse", "parameters": {"pointerType": "mouse"}, "actions": steps}]
        if pan:
            actions.append({"type": "key", "id": "keyboard", "actions": [
                {"type": "keyDown", "value": " "},
                *[{"type": "pause", "duration": 0}] * (len(steps) - 2),
                {"type": "keyUp", "value": " "},
            ]})
        send("POST", f"{session}/actions", {"actions": actions})
        send("DELETE", f"{session}/actions")

    def draw(start, end, pan=False):
        target = evaluate(f"return document.elementFromPoint({start[0]}, {start[1]})?.className;")
        assert "interactive" in (target or ""), target
        points = [tuple(round(a + (b - a) * fraction) for a, b in zip(start, end)) for fraction in (0.25, 0.5, 0.75, 1)]
        pointer([
            move(*start), {"type": "pointerDown", "button": 0},
            *(move(*point) for point in points), {"type": "pointerUp", "button": 0},
        ], pan)

    def snapshot():
        return evaluate('return document.querySelector(".board-editor canvas:not(.interactive)").toDataURL();')

    def visual_change(before, description):
        wait_until(lambda: snapshot() != before, description)

    top = evaluate('return Math.round(document.querySelector(".board-editor canvas.interactive").getBoundingClientRect().top);')
    before = snapshot()
    draw((110, top + 148), (177, top + 148))
    visual_change(before, "card drag on canvas")

    click('label:has([data-testid="toolbar-freedraw"])')
    wait_until(lambda: evaluate('return document.querySelector(\'[data-testid="toolbar-freedraw"]\').checked;'), "freehand tool selection")
    before = snapshot()
    draw((640, top + 204), (690, top + 215))
    visual_change(before, "freehand stroke on canvas")

    click('label:has([data-testid="toolbar-text"])')
    wait_until(lambda: evaluate('return document.querySelector(\'[data-testid="toolbar-text"]\').checked;'), "text tool selection")
    pointer([move(655, top + 298), {"type": "pointerDown", "button": 0}, {"type": "pointerUp", "button": 0}])
    wait_until(lambda: evaluate('return !!document.querySelector("textarea.excalidraw-wysiwyg");'), "canvas text editor")
    text = send("POST", f"{session}/element", {"using": "css selector", "value": "textarea.excalidraw-wysiwyg"})
    send("POST", f"{session}/element/{text['element-6066-11e4-a52e-4f735466cecf']}/value", {"text": "Prototype check"})
    assert evaluate('return document.querySelector("textarea.excalidraw-wysiwyg").value;') == "Prototype check"
    send("POST", f"{session}/actions", {"actions": [{"type": "key", "id": "keyboard", "actions": [
        {"type": "keyDown", "value": "\ue00c"}, {"type": "keyUp", "value": "\ue00c"},
    ]}]})

    before = snapshot()
    click(".zoom-in-button")
    visual_change(before, "zoom change on canvas")
    before = snapshot()
    draw((655, top + 215), (694, top + 236), pan=True)
    visual_change(before, "pan change on canvas")
    return ["card drag", "freehand", "text entry", "zoom", "pan"]


def exercise(settings, send, session):
    def evaluate(script):
        return send("POST", f"{session}/execute/sync", {"script": script, "args": []})

    def click(selector):
        element = send("POST", f"{session}/element", {"using": "css selector", "value": selector})
        element_id = element["element-6066-11e4-a52e-4f735466cecf"]
        send("POST", f"{session}/element/{element_id}/click", {})

    brand = json.loads(Path("branding/brand.json").read_text())["displayName"]
    windows = send("GET", f"{session}/window/handles")
    assert len(windows) == 1, windows
    launcher = wait_until(lambda: evaluate('''
        const image = document.querySelector(".app-mark img");
        return image?.naturalWidth ? [document.title, document.querySelector("h1").textContent, location.origin] : null;
    '''), "branded launcher")
    assert launcher == [brand, brand, "tauri://localhost"], launcher
    assert evaluate('return window.EXCALIDRAW_ASSET_PATH === undefined && !document.querySelector(".board-editor");')
    if settings.shell:
        return {"windows": len(windows), "launcher": launcher, "boards": {}}

    evaluate('''
        window.boardSmokePolicyViolations = [];
        window.addEventListener("securitypolicyviolation", (event) => {
            window.boardSmokePolicyViolations.push([event.violatedDirective, event.blockedURI]);
        });
    ''')

    expected = {"empty": 0, "tiny": 25, "ordinary": 180, "normal": 800}
    boards = {}
    interactions = []
    for index, fixture in enumerate(list(expected) + ["normal"] * settings.cycles):
        click(f'#board-size option[value="{fixture}"]')
        click(".board-picker button")
        state = wait_until(lambda: evaluate('''
            const board = document.querySelector('[data-editor-ready="true"]');
            return board && [board.dataset.fixture, Number(board.dataset.initialElements), board.querySelectorAll("canvas").length];
        '''), f"{fixture} editor mount")
        assert state[:2] == [fixture, expected[fixture]] and state[2] >= 2, state
        boards[fixture] = {"elements": state[1], "canvases": state[2]}
        if index == len(expected) - 1:
            font = send("POST", f"{session}/execute/async", {"script": '''
                const done = arguments[arguments.length - 1];
                document.fonts.load('15px "Nunito"', 'Verify the release build').then(
                    (faces) => done({ base: window.EXCALIDRAW_ASSET_PATH, loaded: faces.map(face => face.status) }),
                    (failure) => done({ error: failure.message }),
                );
            ''', "args": []})
            assert font.get("base") == "tauri://localhost/" and "loaded" in font.get("loaded", []), font
            if settings.screenshot:
                png = send("GET", f"{session}/screenshot")
                settings.screenshot.write_bytes(base64.b64decode(png))
            if settings.interactions:
                interactions = exercise_input(send, session, evaluate, click)
        click(".board-header button")
        wait_until(lambda: evaluate('return !document.querySelector(".board-editor") && !!document.querySelector("#board-size");'), "editor unmount")

    violations = evaluate("return window.boardSmokePolicyViolations;")
    # The pinned SDK always declares its CDN fallback, even after a local asset base is set.
    unexpected = [
        [directive, url] for directive, url in violations
        if directive != "font-src" or not url.startswith("https://esm.sh/@excalidraw/excalidraw@0.18.1/dist/prod/fonts/")
    ]
    assert not unexpected, unexpected[:10]
    return {
        "windows": len(windows), "launcher": launcher, "boards": boards,
        "extra_open_close_cycles": settings.cycles, "local_editor_font": font,
        "blocked_upstream_font_fallbacks": len(violations),
        "input_checks": interactions,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("binary", type=Path)
    parser.add_argument("--shell", action="store_true")
    parser.add_argument("--cycles", type=int, default=0)
    parser.add_argument("--interactions", action="store_true")
    parser.add_argument("--screenshot", type=Path)
    settings = parser.parse_args()
    binary = settings.binary.resolve(strict=True)
    port = available_port()
    native_port = available_port()
    while native_port == port:
        native_port = available_port()
    endpoint = f"http://127.0.0.1:{port}"

    def send(method, path, data=None):
        body = None if data is None else json.dumps(data).encode()
        message = request.Request(endpoint + path, data=body, method=method, headers={"Content-Type": "application/json"})
        try:
            with request.urlopen(message, timeout=20) as response:
                return json.load(response)["value"]
        except error.HTTPError as failure:
            raise RuntimeError(f"WebDriver {method} {path} returned {failure.code}: {failure.read().decode()}") from failure

    driver = subprocess.Popen(["tauri-driver", "--port", str(port), "--native-port", str(native_port)])
    session = None
    try:
        wait_until(lambda: send("GET", "/status"), "local WebDriver")
        capabilities = {"browserName": "wry", "tauri:options": {"application": str(binary)}}
        created = send("POST", "/session", {"capabilities": {"alwaysMatch": capabilities}})
        session = f"/session/{created['sessionId']}"
        print(json.dumps(exercise(settings, send, session), indent=2))
    finally:
        try:
            if session:
                send("DELETE", session)
        finally:
            driver.terminate()
            driver.wait(timeout=5)


if __name__ == "__main__":
    main()
